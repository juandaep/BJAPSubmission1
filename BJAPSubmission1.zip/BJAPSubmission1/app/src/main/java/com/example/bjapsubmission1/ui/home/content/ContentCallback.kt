package com.example.bjapsubmission1.ui.home.content

import com.example.bjapsubmission1.model.DataModel

interface ContentCallback {
    fun onItemClicked(data: DataModel)
}